<?php
return [
    'upload_path'    => 'uploads/' . date("Y") . '/' . date('m') . '/',
    'path'           => 'uploads/',    
];